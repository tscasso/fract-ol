# push_swap_visualizer
This python script was created to visualize your work with the PUSH_SWAP
42 Project.

You must put this script in the same path of your program\
You need python3.
You can install it with Brew.\
`Brew install python3`

You may launch the script with : \
python3 pyviz.py \`ruby -e "puts (-200..200).to_a.shuffle.join(' ')"\` \
or any other list of numbers.

You can change the PUSHS_PATH to get to the relative path of your push_swap
You can pause, decrease or increase the speed, or reset at will.

![alt text](https://preview.ibb.co/go8HHx/Screen_Shot_2018_03_20_at_18_04_38.png "Screenshot")

There are certainly many bugs, but it is 100% functional.
